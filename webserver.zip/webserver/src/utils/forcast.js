
const request = require('request');
const forcast = (lat,long,callback) =>
{
    const forcastURL = 'http://api.openweathermap.org/data/2.5/weather?lon=' + lat + '&lat=' + long + '&APPID=46a68630d4c8cb44138f356cb958e99f&lang=en&units=metric';   
    request({url:forcastURL, json:true },(error,response)=>{
   if(error)
   {
      callback('Unable to connect to weather services!',undefined);

   }
   else if(response.body.main.length===0)
   {
       //console.log(response.body);
      callback('Unable to find location, find another location',undefined);
   }
   else
   {
     //console.log(response.body);
      callback(undefined,{
          tempreture : response.body.main.temp,
          wind : response.body.wind.speed,
          humidity : response.body.main.humidity,
          place : response.body.name,
          country : response.body.sys.country,

      })
   }
})
}

module.exports = forcast;