
const request = require('request');
const geocode = (address,callback) =>
{
   const geoURL = 'https://api.mapbox.com/geocoding/v5/mapbox.places/'+address+'.json?limit=2&access_token=pk.eyJ1Ijoic2hpdjA3NyIsImEiOiJjazlyOHZ1YW8wb2liM21wNTB0cXhmbGtmIn0.zU47BWmRb668Ni-VlrqPqw';
   request({url:geoURL, json:true },(error,response)=>{
   if(error)
   {
      callback('Unable to connect to address services!',undefined);

   }
   else if(response.body.features.length=== 0)
   {
      callback('Unable to find location, find another location',undefined);
   }
   else
   {
      callback(undefined,{
          latitude : response.body.features[0].center[0],
          longitude : response.body.features[0].center[1],

      })
   }
})
}

module.exports = geocode;