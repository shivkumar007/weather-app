const express = require("express");
const path = require("path");
const hbs = require("hbs");
const geocode = require('./utils/geocode');
const forcast = require('./utils/forcast');
const app = express();


// define config path
const publicDirectory = path.join(__dirname, "../public");
const templatePath = path.join(__dirname, "../templates/views");
const partialPath = path.join(__dirname, "../templates/partials");

// setup handlebar engine to render template
app.set("view engine", "hbs");
app.set("views", templatePath);
hbs.registerPartials(partialPath);

//setup static direcoty to serve pages
app.use(express.static(publicDirectory));

app.get("/home", (req, res) => {
  res.render("index", {
    title: "Weather app ",
    name: "Shiv Kumar varma",
  });
});

app.get("/about", (req, res) => {
  res.render("about", {
    title: "About Page ",
    name: "Shiv Kumar varma",
    img_src: "/img/army.png",
  });
});

app.get("/help", (req, res) => {
  res.render("help", {
    title: "Help page",
    name: "Shiv Kumar varma",
  });
});

app.get("/weather", (req, res) => {
    if(!req.query.address)
    {
        res.send({
            error :'You must provide an address!'
        })
    }
    else
    {
        geocode(req.query.address, (error, data) => {
            if(error)
            {
                res.send({
                    error:error
                });
            //    return console.log(error);
            }else{
               forcast(data.latitude, data.longitude, (error, forcastData) => {
                  if(error)
                  {
                    //  return console.log(error);
                    res.send({
                        error:error
                    });
                  }
                  else
                  {
                      res.send({
                        address : forcastData.place+' '+forcastData.country,
                        forcast : 'Current tempreture is '+forcastData.tempreture+ ' degree ,wind speed is ' + forcastData.wind +' & Humidity is'+forcastData.humidity,
                      });
                    // console.log(forcastData.place+' '+forcastData.country);
                    // console.log('Current tempreture is '+forcastData.tempreture+ ' degree ,wind speed is ' + forcastData.wind +' & Humidity is'+forcastData.humidity);
                  }
                
                 
               }); 
            }
               
            });
    }




});

app.get("/products", (req, res) => {
    console.log(req.query.search);
    console.log(req.query.rating);
    if(!req.query.search)
    {
        res.send({
            error:'You must provide a search term'
        })
    }
    res.send({
      products : [],
    });
  });


//404 page

app.get("/help/*", (req, res) => {
  res.render("404help");

  // res.send('404 page')
});

app.get("*", (req, res) => {
  res.render("404Page");

  // res.send('404 page')
});

app.listen(3000, () => {
  console.log("server is up at port 3000");
});
