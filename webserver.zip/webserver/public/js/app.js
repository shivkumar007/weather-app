console.log('Client side js file loaded')

const weather_form = document.querySelector('form');
const geoAddress = document.querySelector('input');
const message = document.querySelector('#dynamic_temp');
weather_form.addEventListener('submit',(e) =>
{
    e.preventDefault();
    let location = document.getElementById('geoAddress').value;
    if(!location)
    {
        return console.log('Please provide location!');
    }
    // let val = geoAddress.value;
    fetch('http://localhost:3000/weather?address='+location).then((response) =>{
        response.json().then((data) =>{
            if(data.error)
            {
                console.log(error);
            }
            else
            {
                console.log(data.address);
                console.log(data.forcast)
                message.textContent = data.forcast
                // document.getElementById('dynamic_temp').html('<h4>'+data.forcast+'</h4>')
            }
        });
    })
    
})